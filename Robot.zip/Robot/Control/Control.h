/*
 * Math_RAP.h
 *
 *  Created on: 12/02/2018
 *      Author: josepablocb
 */

#ifndef UTILS_CONTROL_CONTROL_H_
#define UTILS_CONTROL_CONTROL_H_

#ifndef _PID_DATA_TYPE_
    #define _PID_DATA_TYPE_ Encoder_vel
#endif
#include "PID.h"

#endif /* UTILS_CONTROL_CONTROL_H_ */
